/****************************************************************************
** Meta object code from reading C++ file 'imagewidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../baobao_Painter/imagewidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'imagewidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ImageWidget_t {
    QByteArrayData data[38];
    char stringdata0[374];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ImageWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ImageWidget_t qt_meta_stringdata_ImageWidget = {
    {
QT_MOC_LITERAL(0, 0, 11), // "ImageWidget"
QT_MOC_LITERAL(1, 12, 17), // "statusbar2Message"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 4), // "pick"
QT_MOC_LITERAL(4, 36, 5), // "color"
QT_MOC_LITERAL(5, 42, 7), // "newfile"
QT_MOC_LITERAL(6, 50, 9), // "drawPoint"
QT_MOC_LITERAL(7, 60, 8), // "drawLine"
QT_MOC_LITERAL(8, 69, 9), // "drawArrow"
QT_MOC_LITERAL(9, 79, 8), // "drawRect"
QT_MOC_LITERAL(10, 88, 11), // "drawEllipse"
QT_MOC_LITERAL(11, 100, 8), // "drawText"
QT_MOC_LITERAL(12, 109, 8), // "drawFill"
QT_MOC_LITERAL(13, 118, 9), // "drawErase"
QT_MOC_LITERAL(14, 128, 8), // "drawMove"
QT_MOC_LITERAL(15, 137, 14), // "drawRectSelect"
QT_MOC_LITERAL(16, 152, 11), // "colorPicker"
QT_MOC_LITERAL(17, 164, 9), // "cutSelect"
QT_MOC_LITERAL(18, 174, 9), // "delSelect"
QT_MOC_LITERAL(19, 184, 6), // "zoomin"
QT_MOC_LITERAL(20, 191, 7), // "zoomout"
QT_MOC_LITERAL(21, 199, 5), // "zoom1"
QT_MOC_LITERAL(22, 205, 9), // "selectAll"
QT_MOC_LITERAL(23, 215, 4), // "undo"
QT_MOC_LITERAL(24, 220, 4), // "redo"
QT_MOC_LITERAL(25, 225, 7), // "matting"
QT_MOC_LITERAL(26, 233, 6), // "moveUp"
QT_MOC_LITERAL(27, 240, 8), // "moveDown"
QT_MOC_LITERAL(28, 249, 8), // "moveLeft"
QT_MOC_LITERAL(29, 258, 9), // "moveRight"
QT_MOC_LITERAL(30, 268, 9), // "moveTopUp"
QT_MOC_LITERAL(31, 278, 11), // "moveTopDown"
QT_MOC_LITERAL(32, 290, 12), // "moveLeftLeft"
QT_MOC_LITERAL(33, 303, 13), // "moveLeftRight"
QT_MOC_LITERAL(34, 317, 13), // "moveRightLeft"
QT_MOC_LITERAL(35, 331, 14), // "moveRightRight"
QT_MOC_LITERAL(36, 346, 12), // "moveBottomUp"
QT_MOC_LITERAL(37, 359, 14) // "moveBottomDown"

    },
    "ImageWidget\0statusbar2Message\0\0pick\0"
    "color\0newfile\0drawPoint\0drawLine\0"
    "drawArrow\0drawRect\0drawEllipse\0drawText\0"
    "drawFill\0drawErase\0drawMove\0drawRectSelect\0"
    "colorPicker\0cutSelect\0delSelect\0zoomin\0"
    "zoomout\0zoom1\0selectAll\0undo\0redo\0"
    "matting\0moveUp\0moveDown\0moveLeft\0"
    "moveRight\0moveTopUp\0moveTopDown\0"
    "moveLeftLeft\0moveLeftRight\0moveRightLeft\0"
    "moveRightRight\0moveBottomUp\0moveBottomDown"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ImageWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      35,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  189,    2, 0x06 /* Public */,
       3,    1,  192,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,  195,    2, 0x0a /* Public */,
       6,    0,  196,    2, 0x0a /* Public */,
       7,    0,  197,    2, 0x0a /* Public */,
       8,    0,  198,    2, 0x0a /* Public */,
       9,    0,  199,    2, 0x0a /* Public */,
      10,    0,  200,    2, 0x0a /* Public */,
      11,    0,  201,    2, 0x0a /* Public */,
      12,    0,  202,    2, 0x0a /* Public */,
      13,    0,  203,    2, 0x0a /* Public */,
      14,    0,  204,    2, 0x0a /* Public */,
      15,    0,  205,    2, 0x0a /* Public */,
      16,    0,  206,    2, 0x0a /* Public */,
      17,    0,  207,    2, 0x0a /* Public */,
      18,    0,  208,    2, 0x0a /* Public */,
      19,    0,  209,    2, 0x0a /* Public */,
      20,    0,  210,    2, 0x0a /* Public */,
      21,    0,  211,    2, 0x0a /* Public */,
      22,    0,  212,    2, 0x0a /* Public */,
      23,    0,  213,    2, 0x0a /* Public */,
      24,    0,  214,    2, 0x0a /* Public */,
      25,    0,  215,    2, 0x0a /* Public */,
      26,    0,  216,    2, 0x08 /* Private */,
      27,    0,  217,    2, 0x08 /* Private */,
      28,    0,  218,    2, 0x08 /* Private */,
      29,    0,  219,    2, 0x08 /* Private */,
      30,    0,  220,    2, 0x08 /* Private */,
      31,    0,  221,    2, 0x08 /* Private */,
      32,    0,  222,    2, 0x08 /* Private */,
      33,    0,  223,    2, 0x08 /* Private */,
      34,    0,  224,    2, 0x08 /* Private */,
      35,    0,  225,    2, 0x08 /* Private */,
      36,    0,  226,    2, 0x08 /* Private */,
      37,    0,  227,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QColor,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ImageWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ImageWidget *_t = static_cast<ImageWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->statusbar2Message((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->pick((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 2: _t->newfile(); break;
        case 3: _t->drawPoint(); break;
        case 4: _t->drawLine(); break;
        case 5: _t->drawArrow(); break;
        case 6: _t->drawRect(); break;
        case 7: _t->drawEllipse(); break;
        case 8: _t->drawText(); break;
        case 9: _t->drawFill(); break;
        case 10: _t->drawErase(); break;
        case 11: _t->drawMove(); break;
        case 12: _t->drawRectSelect(); break;
        case 13: _t->colorPicker(); break;
        case 14: _t->cutSelect(); break;
        case 15: _t->delSelect(); break;
        case 16: _t->zoomin(); break;
        case 17: _t->zoomout(); break;
        case 18: _t->zoom1(); break;
        case 19: _t->selectAll(); break;
        case 20: _t->undo(); break;
        case 21: _t->redo(); break;
        case 22: _t->matting(); break;
        case 23: _t->moveUp(); break;
        case 24: _t->moveDown(); break;
        case 25: _t->moveLeft(); break;
        case 26: _t->moveRight(); break;
        case 27: _t->moveTopUp(); break;
        case 28: _t->moveTopDown(); break;
        case 29: _t->moveLeftLeft(); break;
        case 30: _t->moveLeftRight(); break;
        case 31: _t->moveRightLeft(); break;
        case 32: _t->moveRightRight(); break;
        case 33: _t->moveBottomUp(); break;
        case 34: _t->moveBottomDown(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ImageWidget::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ImageWidget::statusbar2Message)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (ImageWidget::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ImageWidget::pick)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject ImageWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ImageWidget.data,
      qt_meta_data_ImageWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *ImageWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ImageWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ImageWidget.stringdata0))
        return static_cast<void*>(const_cast< ImageWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int ImageWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 35)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 35;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 35)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 35;
    }
    return _id;
}

// SIGNAL 0
void ImageWidget::statusbar2Message(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ImageWidget::pick(QColor _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
